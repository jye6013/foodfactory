<!DOCTYPE html>
<!--Ji Ye-->
<html> 
	<head>
        <link href="https://fonts.googleapis.com/css?family=Bubbler+One" rel="stylesheet">
		<title> </title>
		<style>
            *
            {
                text-align: center;
                font-family: 'Bubbler One', sans-serif;
            }
            
            .text
            {
                margin-top: 300px;
                font-size: 30px;
            }
		</style>                                                                 
		<script onload = "">
			
		</script>
	</head>
	<body>
		<a href = "index.html">Return Home</a>
		<p class= "text">Thank you for your time!</p>
        <body background = "images/raspberry.jpg">
	</body> 
</html>
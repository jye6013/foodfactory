<!DOCTYPE html>
<!--Ji Ye-->
<html> 
	<head>
        <link href="https://fonts.googleapis.com/css?family=Bubbler+One" rel="stylesheet">
		<title> </title>
		<style>
            *
            {
                color: white;
                font-family: 'Bubbler One', sans-serif;
                text-align: center;
            }
		</style>                                                                 
		<script onload = "">
			
		</script>
	</head>
	<body>
        <a href = "homepage.html">Return Home</a>
        <h1 class = "title">FoodFactory</h1>
        
        <div>My Cart</div>
        <?php
            echo $_POST["tomatoQuan"];
        ?>
        <body background = "images/food.jpg">
	</body> 
</html>
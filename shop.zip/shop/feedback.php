<!DOCTYPE html>
<!--Ji Ye-->
<html> 
	<head>
        <link href="https://fonts.googleapis.com/css?family=Bubbler+One" rel="stylesheet">
		<title> </title>
		<style>
			*
            {
                text-align: center;
                font-family: 'Bubbler One', sans-serif;
            }
            
            .button
            {
                border-radius: 50px;
            }
		</style>                                                                 
		<script onload = "">
			
		</script>
	</head>
	<body>
        <a href = "index.html">Return Home</a>
		<h1>Feedback Form</h1>
        <form method = "post" action = "feedback2.php">
            <p>Order Number: <input type = "text"></p>
            <p>First Name: <input type = "text"> Last Name: <input type = "text"></p>
            <p>Email: <input type = "text"></p>
            Comment:
            <p><textarea rows="10" cols="50"></textarea></p>
            <p><input class = "button" type = "submit" /></p>
		</form>
        <body background = "images/raspberry.jpg">
	</body> 
</html>